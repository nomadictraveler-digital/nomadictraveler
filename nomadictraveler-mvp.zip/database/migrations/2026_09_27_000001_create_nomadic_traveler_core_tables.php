<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('membership_plans', function(Blueprint $t) {
            $t->id(); $t->string('name'); $t->string('slug')->unique();
            $t->decimal('price',10,2)->default(0); $t->string('currency',3)->default('BDT');
            $t->boolean('is_active')->default(true); $t->timestamps();
        });
        Schema::create('profiles', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->unique()->constrained()->cascadeOnDelete();
            $t->string('display_name')->nullable(); $t->text('bio')->nullable();
            $t->string('country')->nullable(); $t->string('city')->nullable();
            $t->string('avatar_path')->nullable(); $t->timestamps();
        });
        Schema::create('subscriptions', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('membership_plan_id')->constrained()->restrictOnDelete();
            $t->date('starts_at'); $t->date('ends_at')->nullable();
            $t->string('status')->default('active'); $t->timestamps();
        });
        Schema::create('countries', function(Blueprint $t) {
            $t->id(); $t->string('name'); $t->string('iso2',2)->unique();
            $t->string('slug')->unique(); $t->boolean('is_active')->default(true); $t->timestamps();
        });
        Schema::create('visa_guides', function(Blueprint $t) {
            $t->id(); $t->foreignId('country_id')->constrained()->cascadeOnDelete();
            $t->string('visa_type'); $t->text('summary')->nullable();
            $t->text('requirements')->nullable(); $t->text('processing_info')->nullable();
            $t->string('source_url')->nullable(); $t->timestamp('verified_at')->nullable(); $t->timestamps();
        });
        Schema::create('visa_applications', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('country_id')->constrained()->restrictOnDelete();
            $t->string('visa_type'); $t->string('status')->default('submitted');
            $t->decimal('service_fee',10,2)->default(5000); $t->text('notes')->nullable(); $t->timestamps();
        });
        Schema::create('visa_documents', function(Blueprint $t) {
            $t->id(); $t->foreignId('visa_application_id')->constrained()->cascadeOnDelete();
            $t->string('document_type'); $t->string('file_path'); $t->string('original_name')->nullable();
            $t->string('status')->default('uploaded'); $t->timestamps();
        });
        Schema::create('hotel_requests', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('destination'); $t->date('check_in'); $t->date('check_out');
            $t->unsignedInteger('guests')->default(1); $t->text('requirements')->nullable();
            $t->string('status')->default('submitted'); $t->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete(); $t->timestamps();
        });
        Schema::create('flight_requests', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('origin'); $t->string('destination'); $t->date('departure');
            $t->date('return')->nullable(); $t->unsignedInteger('passengers')->default(1);
            $t->text('notes')->nullable(); $t->string('status')->default('submitted');
            $t->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete(); $t->timestamps();
        });
        Schema::create('posts', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->text('body')->nullable(); $t->string('media_path')->nullable();
            $t->string('media_type')->nullable(); $t->timestamps();
        });
        Schema::create('comments', function(Blueprint $t) {
            $t->id(); $t->foreignId('post_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->text('body'); $t->timestamps();
        });
        Schema::create('reactions', function(Blueprint $t) {
            $t->id(); $t->foreignId('post_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('type')->default('like');
            $t->unique(['post_id','user_id','type']); $t->timestamps();
        });
        Schema::create('groups', function(Blueprint $t) {
            $t->id(); $t->string('name'); $t->string('slug')->unique(); $t->text('description')->nullable();
            $t->foreignId('country_id')->nullable()->constrained()->nullOnDelete(); $t->timestamps();
        });
        Schema::create('events', function(Blueprint $t) {
            $t->id(); $t->string('title'); $t->text('description')->nullable();
            $t->string('location')->nullable(); $t->dateTime('starts_at'); $t->dateTime('ends_at')->nullable(); $t->timestamps();
        });
        Schema::create('messages', function(Blueprint $t) {
            $t->id(); $t->foreignId('sender_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('recipient_id')->constrained('users')->cascadeOnDelete();
            $t->text('body'); $t->timestamp('read_at')->nullable(); $t->timestamps();
        });
        Schema::create('payments', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('purpose'); $t->decimal('amount',10,2); $t->string('currency',3)->default('BDT');
            $t->string('method')->nullable(); $t->string('transaction_id')->nullable();
            $t->string('status')->default('pending'); $t->string('proof_path')->nullable(); $t->timestamps();
        });
        Schema::create('support_tickets', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('subject'); $t->text('message'); $t->string('status')->default('open');
            $t->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete(); $t->timestamps();
        });
        Schema::create('audit_logs', function(Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('action'); $t->string('entity_type')->nullable(); $t->unsignedBigInteger('entity_id')->nullable();
            $t->json('meta')->nullable(); $t->ipAddress('ip_address')->nullable(); $t->timestamps();
        });
    }
    public function down(): void {
        foreach (['audit_logs','support_tickets','payments','messages','events','groups','reactions','comments','posts','flight_requests','hotel_requests','visa_documents','visa_applications','visa_guides','countries','subscriptions','profiles','membership_plans'] as $t) Schema::dropIfExists($t);
    }
};
