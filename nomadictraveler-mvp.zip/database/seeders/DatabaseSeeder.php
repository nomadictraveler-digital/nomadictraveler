<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('membership_plans')->insert([
            ['name'=>'FREE','slug'=>'free','price'=>0,'currency'=>'BDT','is_active'=>1],
            ['name'=>'EXPLORER','slug'=>'explorer','price'=>500,'currency'=>'BDT','is_active'=>1],
            ['name'=>'PREMIUM','slug'=>'premium','price'=>1000,'currency'=>'BDT','is_active'=>1],
            ['name'=>'VIP','slug'=>'vip','price'=>2000,'currency'=>'BDT','is_active'=>1],
        ]);
    }
}
