<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'dashboard.home')->name('home');

Route::view('/dashboard', 'dashboard.index')
    ->middleware(['auth'])
    ->name('dashboard');

Route::view('/visa', 'visa.index')->name('visa.index');
Route::view('/community', 'community.index')->name('community.index');
Route::view('/hotel-request', 'bookings.hotel')->name('hotel.request');
Route::view('/flight-request', 'bookings.flight')->name('flight.request');
Route::view('/membership', 'membership.index')->name('membership.index');

Route::prefix('admin')->middleware(['auth'])->group(function () {
    Route::view('/', 'admin.index')->name('admin.index');
});
