# Nomadic Traveler — MVP Blueprint

## Brand
Digital Nomad | nomadictraveler.org

## Membership
| Plan | Price |
|---|---:|
| FREE | ৳0 |
| EXPLORER | ৳500 |
| PREMIUM | ৳1,000 |
| VIP | ৳2,000 |

## Visa
- Information + service
- Country scope: All
- Default service fee: ৳5,000
- Workflow: Submitted → Under Review → Document Required → Processing → Approved/Rejected

## Bookings
- Hotel: manual request/quotation/confirmation
- Flight: manual request/quotation/ticket document

## Community
Posts, photo/video, comments, likes, shares, groups, Travel Buddy, events, meetups, private messaging, country communities.

## Staff roles
Super Admin, Community Manager, Visa Officer, Flight Agent, Hotel Agent, Accountant, Support Agent, Content Editor.

## Payments
MVP supports manual payment recording. Gateway integrations can be added later.
