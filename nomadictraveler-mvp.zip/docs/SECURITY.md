# Security Checklist

- HTTPS only in production
- Strong password hashing
- Email verification
- CSRF protection
- Rate limiting for authentication and messaging
- Server-side authorization/policies
- Private document storage
- MIME/type and size validation
- Malware scanning for uploaded files before operational use
- Audit logs for staff actions
- Database backups and restore testing
- Admin 2FA before production
- Secrets only in environment variables
- Regular Laravel/PHP/dependency updates
