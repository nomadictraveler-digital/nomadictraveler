# Core Database

Core MVP entities:
users, profiles, membership_plans, subscriptions, payments, invoices,
countries, visa_types, visa_guides, visa_requirements, visa_applications,
visa_documents, hotel_requests, hotel_quotes, hotel_bookings,
flight_requests, flight_quotes, flight_bookings,
posts, comments, reactions, groups, group_members, events, event_attendance,
travel_buddies, messages, notifications, support_tickets, audit_logs.

Files containing passport or visa documents must use private storage and authorization checks.
