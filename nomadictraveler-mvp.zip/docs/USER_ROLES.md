# User & Staff Roles

## Staff
- super_admin: full platform control
- community_manager: community moderation and groups/events
- visa_officer: visa guides/applications/documents
- flight_agent: flight requests/quotes/tickets
- hotel_agent: hotel requests/quotes/bookings
- accountant: payments/invoices/financial records
- support_agent: tickets/user support
- content_editor: countries/visa guides/content

Use policy-based authorization and server-side permission checks. Never rely only on hidden UI controls.
