@extends('layouts.app')
@section('content')
<h1>My Dashboard</h1>
<div class="alert alert-info">Your applications, bookings, membership, documents and messages will appear here.</div>
@endsection
