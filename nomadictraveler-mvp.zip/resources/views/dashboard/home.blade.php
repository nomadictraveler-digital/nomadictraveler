@extends('layouts.app')
@section('content')
<div class="py-5">
<h1>Travel Beyond Limits</h1>
<p class="lead">Nomadic Traveler — Digital Nomad community and travel services.</p>
<div class="row g-3 mt-3">
@foreach([['Visa','Global visa information and visa service applications.',route('visa.index')],
['Community','Connect with travelers, groups, events and Travel Buddy.',route('community.index')],
['Hotel','Submit a manual hotel booking request.',route('hotel.request')],
['Flight','Submit a manual flight assistance request.',route('flight.request')]] as $item)
<div class="col-md-6"><div class="card h-100"><div class="card-body"><h3>{{ $item[0] }}</h3><p>{{ $item[1] }}</p><a class="btn btn-dark" href="{{ $item[2] }}">Open</a></div></div></div>
@endforeach
</div>
</div>
@endsection
