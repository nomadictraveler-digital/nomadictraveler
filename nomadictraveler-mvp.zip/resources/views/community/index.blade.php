@extends('layouts.app')
@section('content')
<h1>Community</h1>
<p>Posts · Photo/Video · Comments · Likes · Shares · Groups · Travel Buddy · Events · Meetups · Private Messages · Country Communities</p>
@endsection
