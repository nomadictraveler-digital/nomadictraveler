@extends('layouts.app')
@section('content')
<h1>Flight Assistance Request</h1>
<form method="post" action="#"><input type="hidden" name="_token" value="{{ csrf_token() }}">
<div class="row g-3">
<div class="col-md-6"><label>From</label><input class="form-control" name="from"></div>
<div class="col-md-6"><label>To</label><input class="form-control" name="to"></div>
<div class="col-md-4"><label>Departure</label><input type="date" class="form-control" name="departure"></div>
<div class="col-md-4"><label>Return</label><input type="date" class="form-control" name="return"></div>
<div class="col-md-4"><label>Passengers</label><input type="number" class="form-control" name="passengers" min="1"></div>
<div class="col-12"><label>Notes</label><textarea class="form-control" name="notes"></textarea></div>
</div><button class="btn btn-dark mt-3">Submit Request</button></form>
@endsection
