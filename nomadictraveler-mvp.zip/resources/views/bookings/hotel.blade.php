@extends('layouts.app')
@section('content')
<h1>Hotel Booking Request</h1>
<form method="post" action="#"><input type="hidden" name="_token" value="{{ csrf_token() }}">
<div class="row g-3">
<div class="col-md-6"><label>Destination</label><input class="form-control" name="destination"></div>
<div class="col-md-3"><label>Check-in</label><input type="date" class="form-control" name="check_in"></div>
<div class="col-md-3"><label>Check-out</label><input type="date" class="form-control" name="check_out"></div>
<div class="col-md-6"><label>Guests</label><input type="number" class="form-control" name="guests" min="1"></div>
<div class="col-12"><label>Requirements</label><textarea class="form-control" name="requirements"></textarea></div>
</div><button class="btn btn-dark mt-3">Submit Request</button></form>
@endsection
