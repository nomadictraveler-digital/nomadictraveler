<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name', 'Nomadic Traveler') }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
<div class="container">
<a class="navbar-brand" href="{{ route('home') }}">Nomadic Traveler</a>
<div class="navbar-nav">
<a class="nav-link" href="{{ route('visa.index') }}">Visa</a>
<a class="nav-link" href="{{ route('community.index') }}">Community</a>
<a class="nav-link" href="{{ route('membership.index') }}">Membership</a>
<a class="nav-link" href="{{ route('hotel.request') }}">Hotel</a>
<a class="nav-link" href="{{ route('flight.request') }}">Flight</a>
</div>
</div>
</nav>
<main class="container py-4">@yield('content')</main>
</body>
</html>
