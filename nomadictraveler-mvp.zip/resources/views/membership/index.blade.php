@extends('layouts.app')
@section('content')
<h1>Membership</h1>
<div class="row g-3">
@foreach([['FREE','৳0'],['EXPLORER','৳500'],['PREMIUM','৳1,000'],['VIP','৳2,000']] as $plan)
<div class="col-md-3"><div class="card h-100"><div class="card-body"><h3>{{ $plan[0] }}</h3><p class="display-6">{{ $plan[1] }}</p><button class="btn btn-outline-dark">Choose</button></div></div></div>
@endforeach
</div>
@endsection
