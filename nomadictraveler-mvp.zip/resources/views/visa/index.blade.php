@extends('layouts.app')
@section('content')
<h1>Visa Information & Services</h1>
<p>Search country-specific visa information and submit a visa-service application.</p>
<div class="alert alert-secondary">MVP default service fee: ৳5,000. Final fees can be configured by administrators.</div>
@endsection
