@extends('layouts.app')
@section('content')
<h1>Admin Dashboard</h1>
<div class="row g-3">
@foreach(['Users','Memberships','Visa Applications','Hotel Requests','Flight Requests','Community','Payments','Support','Content','Audit Logs'] as $item)
<div class="col-md-4"><div class="card"><div class="card-body"><h5>{{ $item }}</h5><button class="btn btn-sm btn-dark">Manage</button></div></div></div>
@endforeach
</div>
@endsection
